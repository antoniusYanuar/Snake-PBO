/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app;

/**
 *
 * @author Asus
 */
public interface Choice {
    
    public final int left = 1;
    public final int right = -1;
    public final int up = 2;
    public final int down = -2;
    
}
