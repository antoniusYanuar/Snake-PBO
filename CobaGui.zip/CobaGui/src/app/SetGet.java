/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app;

/**
 *
 * @author WIN 10
 */
public class SetGet {
    public int sheight;
    public int swidth;

    public int getSheight() {
        return sheight;
    }

    public void setSheight(int sheight) {
        this.sheight = sheight;
    }

    public int getSwidth() {
        return swidth;
    }

    public void setSwidth(int swidth) {
        this.swidth = swidth;
    }
    
}
