/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import java.sql.*;
/**
 *
 * @author Jeer
 */
public class ScoreDB {
   
    int score;

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }
    
    public ScoreDB(){
        initAll();
    }
    public void initAll(){
        try{ 
            String URL="jdbc:mysql://localhost:3306/snake";
            Connection dbCon = DriverManager.getConnection(URL, "root","");
            System.out.println("koneksi ke DB berhasil.");
            
            
        }catch(SQLException ex){
            System.out.println("Gagal koneksi ke DB: "+ex.getMessage());
            
            
        }
        try { 
            String URL="jdbc:mysql://localhost:3306/snake";
            Connection dbCon = DriverManager.getConnection(URL, "root","");
            Statement st = dbCon.createStatement(); 
            st.executeUpdate("INSERT INTO score(score) " + 
                "VALUES("+score+")"); 

            dbCon.close(); 
        } catch (Exception e) { 
            System.err.println("Got an exception! "); 
            System.err.println(e.getMessage()); 
        } 
    }
}
